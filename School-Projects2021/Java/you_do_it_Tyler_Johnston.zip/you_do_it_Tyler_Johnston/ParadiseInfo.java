/*
Name: Tyler Johnston
Summary of Program: ParadiseInfo number 1
Current Date: 4 FEB 2021
*/
public class ParadiseInfo {
    public static void main(String[] args)
    {
        displayInfo();
    }
    public static void displayInfo()
    {
    System.out.println("Paradise Day Spa wants to pamper you."); // print
    System.out.println("We will make you look good."); // print
    }
}