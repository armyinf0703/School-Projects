/*
Name: Tyler Johnston
Summary of Program: For showing a test import 
Current Date: 4 FEB 2021
*/
public class TestInfo
{
public static void main(String[] args)
{
System.out.println("Calling method from another class:");// Print saying This is being called from another class.
ParadiseInfo.displayInfo(); //Calling a display method from another file
}
}